using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

using EezeeScript;

namespace Demo
{
    public enum NPCDirection
    {
        Dowm,
        Left,
        Right,
        Up
    }

    public class NPC
        : ScriptHandler
    {
        private Image m_imageSprites;
        private TextWindow m_textWindow;
        private ScriptContext m_scriptContext;
        private NPCDirection m_npcDirection;
        private int m_iPosX;
        private int m_iPosY;
        private int m_iPause;
        private int m_iMoveX;
        private int m_iMoveY;
        private int m_iFrame;

        public NPC(Image imageSprites, Script script, TextWindow textWindow)
        {
            m_imageSprites = imageSprites;
            m_textWindow = textWindow;
            m_scriptContext = new ScriptContext(script);
            m_scriptContext.InterruptOnCustomCommand = true;
            m_scriptContext.Handler = this;
            m_npcDirection = NPCDirection.Dowm;
            m_iPosX = 0;
            m_iPosY = 0;
            m_iPause = 0;
            m_iMoveX = 0;
            m_iMoveY = 0;
            m_iFrame = 0;
        }

        public void Update()
        {
            if ( m_iMoveX == 0 && m_iMoveY == 0 && m_iPause == 0)
                m_scriptContext.Execute();

            if (m_iMoveX != 0 || m_iMoveY != 0)
                m_iFrame = (m_iFrame + 1) % 16;
            else
                m_iFrame = 0;

            if (m_iPause > 0)
                --m_iPause;

            if (m_iMoveX > 0)
            {
                m_iPosX += 2;
                m_iMoveX -= 2;
            }

            if (m_iMoveX < 0)
            {
                m_iPosX -= 2;
                m_iMoveX += 2;
            }

            if (m_iMoveY > 0)
            {
                m_iPosY += 2;
                m_iMoveY -= 2;
            }

            if (m_iMoveY < 0)
            {
                m_iPosY -= 2;
                m_iMoveY += 2;
            }
        }

        public void OnScriptCommand(ScriptContext scriptContext,
            String strCommand, List<object> listParameters)
        {
            if (strCommand == "SetNPCPosition")
            {
                m_iPosX = (int)listParameters[0];
                m_iPosY = (int)listParameters[1];
                m_iMoveX = 0;
                m_iMoveY = 0;
            }
            else if (strCommand == "SetNPCDirection")
            {
                String strValue = ((String)listParameters[0]).ToUpper();
                if (strValue == "DOWN")
                    m_npcDirection = NPCDirection.Dowm;
                else if (strValue == "LEFT")
                    m_npcDirection = NPCDirection.Left;
                else if (strValue == "RIGHT")
                    m_npcDirection = NPCDirection.Right;
                else if (strValue == "UP")
                    m_npcDirection = NPCDirection.Up;
            }
            else if (strCommand == "MoveNPC")
            {
                m_iMoveX = (int)listParameters[0];
                m_iMoveY = (int)listParameters[1];
            }
            else if (strCommand == "MoveNPCTo")
            {
                int iTargetX = (int)listParameters[0];
                int iTargetY = (int)listParameters[1];

                m_iMoveX = iTargetX - m_iPosX;
                m_iMoveY = iTargetY - m_iPosY;
            }
            else if (strCommand == "PauseNPC")
            {
                m_iPause = (int)listParameters[0];
            }
            else if (strCommand == "SayNPC")
            {
                m_textWindow.Say(this, (String)listParameters[0], (int) listParameters[1]);
            }
        }

        public void OnScriptVariableUpdate(ScriptContext scriptContext,
            String strIdentifier, object objectValue)
        {
        }

        public void OnScriptInterrupt(ScriptContext scriptContext)
        {
        }

        public void Paint(Graphics graphics)
        {
            Rectangle rectSource = new Rectangle();
            rectSource.X = (m_iFrame / 4) * 64;
            rectSource.Y = ((int)m_npcDirection) * 96;
            rectSource.Width = 64;
            rectSource.Height = 96;
    
            Rectangle rectDest = new Rectangle();
            rectDest.X = m_iPosX - 32;
            rectDest.Y = m_iPosY - 96;
            rectDest.Width = 64;
            rectDest.Height = 96;

            graphics.DrawImage(m_imageSprites, rectDest, rectSource, GraphicsUnit.Pixel);
        }

        public void PaintFace(Graphics graphics)
        {
            graphics.DrawImage(m_imageSprites,
                new Rectangle(32, 396, 64, 48),
                new Rectangle(0, 0, 64, 48),
                GraphicsUnit.Pixel);
        }

        public ScriptContext ScriptContext
        {
            get { return m_scriptContext; }
        }
    }
}
