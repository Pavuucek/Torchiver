using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Demo
{
    public class TextWindow
    {
        private int m_iTicks;
        private String m_strMessage;
        private NPC m_npc;
        private Font m_font;

        public TextWindow()
        {
            m_iTicks = 0;
            m_strMessage = "";
            m_npc = null;
            m_font = new Font(FontFamily.GenericSansSerif, 12, FontStyle.Regular);
        }

        public void Say(NPC npc, String strMessage, int iTicks)
        {
            m_npc = npc;
            m_strMessage = strMessage;
            m_iTicks = iTicks;
        }

        public void Update()
        {
            if (m_iTicks > 0) --m_iTicks;
        }

        public void Paint(Graphics graphics)
        {
            if (m_iTicks <= 0) return;

            Image imageTextWindow = Demo.Properties.Resources.TextWindow;
            graphics.DrawImage(imageTextWindow, new Rectangle(0, 360, 640, 120), new Rectangle(0, 0, 640, 120), GraphicsUnit.Pixel);

            if (m_npc != null)
                m_npc.PaintFace(graphics);

            graphics.DrawString(m_strMessage, m_font, Brushes.Black, 113, 405);
            graphics.DrawString(m_strMessage, m_font, Brushes.White, 112, 404);
        }
    }
}
