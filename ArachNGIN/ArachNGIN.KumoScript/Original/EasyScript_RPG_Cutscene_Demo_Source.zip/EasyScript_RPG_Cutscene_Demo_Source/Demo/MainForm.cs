using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using EezeeScript;

namespace Demo
{
    public partial class MainForm : Form
    {
        private TextWindow m_textWindow;
        private NPC m_npc00;
        private NPC m_npc01;
        private NPC m_npc02;

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ScriptManager scriptManager = new ScriptManager();

            CommandPrototype commandPrototype = null;
            
            commandPrototype = new CommandPrototype("SetNPCPosition");
            commandPrototype.AddParameterType(typeof(int));
            commandPrototype.AddParameterType(typeof(int));
            scriptManager.RegisterCommand(commandPrototype);

            commandPrototype = new CommandPrototype("SetNPCDirection");
            commandPrototype.AddParameterType(typeof(String));
            scriptManager.RegisterCommand(commandPrototype);

            commandPrototype = new CommandPrototype("MoveNPC");
            commandPrototype.AddParameterType(typeof(int));
            commandPrototype.AddParameterType(typeof(int));
            scriptManager.RegisterCommand(commandPrototype);

            commandPrototype = new CommandPrototype("MoveNPCTo");
            commandPrototype.AddParameterType(typeof(int));
            commandPrototype.AddParameterType(typeof(int));
            scriptManager.RegisterCommand(commandPrototype);

            commandPrototype = new CommandPrototype("PauseNPC");
            commandPrototype.AddParameterType(typeof(int));
            scriptManager.RegisterCommand(commandPrototype);

            commandPrototype = new CommandPrototype("SayNPC");
            commandPrototype.AddParameterType(typeof(String));
            commandPrototype.AddParameterType(typeof(int));
            scriptManager.RegisterCommand(commandPrototype);

            Script script = null;

            m_textWindow = new TextWindow();

            script = new Script(scriptManager, "NPC00.ezs");
            m_npc00 = new NPC(Demo.Properties.Resources.NPC00, script, m_textWindow);

            script = new Script(scriptManager, "NPC01.ezs");
            m_npc01 = new NPC(Demo.Properties.Resources.NPC01, script, m_textWindow);

            script = new Script(scriptManager, "NPC02.ezs");
            m_npc02 = new NPC(Demo.Properties.Resources.NPC02, script, m_textWindow);

            m_tmrDisplay.Enabled = true;
        }

        private void m_tmrDisplay_Tick(object sender, EventArgs e)
        {
            if (m_npc00.ScriptContext.Terminated
                && m_npc01.ScriptContext.Terminated
                && m_npc02.ScriptContext.Terminated)
            {
                m_npc00.ScriptContext.Restart();
                m_npc01.ScriptContext.Restart();
                m_npc02.ScriptContext.Restart();
            }

            m_textWindow.Update();
            m_npc00.Update();
            m_npc01.Update();
            m_npc02.Update();
            Invalidate();
        }

        private void MainForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;

            m_npc00.Paint(graphics);
            m_npc01.Paint(graphics);
            m_npc02.Paint(graphics);

            m_textWindow.Paint(graphics);
        }
    }
}